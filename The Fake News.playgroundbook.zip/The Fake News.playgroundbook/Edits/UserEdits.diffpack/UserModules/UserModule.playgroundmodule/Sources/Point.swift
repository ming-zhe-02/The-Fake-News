import SwiftUI


public struct OpenView: View {
    public var body: some View {
        VStack{
            Rectangle()
                .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 178/255, green: 36/255, blue: 239/255), Color(red: 117/255, green: 121/255, blue: 255/255)]), startPoint: .top, endPoint: .bottom ))
                .overlay(
                    ZStack {
                        VStack{
                            // Tittle
                            Text("⚠️HOW TO STOP FAKE NEWS⚠️").font(Font.system(size:30, design: .default))
                            
                            HStack(alignment: .center){
                                Spacer()
                                VStack{
                                    Image(systemName: "person.crop.circle.badge.questionmark")
                                        .font(.system(size: 40))
                                    Text("CONSIDER THE SOURCE").font(Font.system(size:15, design: .default))
                                        .fontWeight(.bold)
                                    Text("Is there an author? Check out their credentials on relevant issues.").font(Font.system(size:10, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                                VStack{
                                    Image(systemName: "doc.text.magnifyingglass")
                                        .font(.system(size: 60))
                                    Text("READ BEYOND").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("Headlines can be outrageous in n effort to get clicks. What's the whole story?").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                            }
                            .padding(.top, 80)
                            
                            HStack(alignment: .center){
                                Spacer()
                                VStack{
                                    Image(systemName: "newspaper")
                                        .font(.system(size: 60))
                                    Text("SUPPORTING SOURCES").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("Click on links or check with offical sources. Do thy support the story?").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                                VStack{
                                    Image(systemName: "person.fill.checkmark")
                                        .font(.system(size: 60))
                                    Text("DO OTHERS AGREE?").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("Are any other sites reporting this? What sources are they citing?").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                            }
                            .padding(.top, 20)
                            
                            HStack(alignment: .center){
                                Spacer()
                                VStack{
                                    Image(systemName: "ear.trianglebadge.exclamationmark")
                                        .font(.system(size: 60))
                                    Text("IS IT A JOKE?").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("If it is too outlandish, It minght be satire, Research the sources to be sure.").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                                VStack{
                                    Image(systemName: "rectangle.3.offgrid.bubble.left")
                                        .font(.system(size: 60))
                                    Text("CHECK YOUR BAISES").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("Consider if your own belifes or concerns ould affect your judgement.").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                            }
                            .padding(.top, 20)
                            
                            HStack(alignment: .center){
                                Spacer()
                                VStack{
                                    Image(systemName: "laptopcomputer.and.iphone")
                                        .font(.system(size: 60))
                                    Text("ASK THE EXPERTS").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("Ask the librarian, or consult a fact-checking site, official source like the WHO.").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                                VStack{
                                    Image(systemName: "eyes.inverse")
                                        .font(.system(size: 60))
                                    Text("LOOK BEFORE YOU SHARE").font(Font.system(size:25, design: .default))
                                        .fontWeight(.bold)
                                    Text("Don't share posts or stories that you haven't check out first.").font(Font.system(size:20, design: .default))
                                }
                                .frame(width: UIScreen.main.bounds.width/5)
                                Spacer()
                            }
                            .padding(.top, 10)
                        }
                    }
                )
        }
        .padding(10)
    }
}
