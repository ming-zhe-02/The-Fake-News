

import SwiftUI


public struct Quiz4: View {
    @Binding var nowPage: String
    
    // alytlics
    @Binding var correct: Int
    @Binding var wrong: Int
    
    @State var select = ""
    @State var answer = "A"
    @State var isSubimt = false
    @State var showHelpView = false
    
    public var body: some View {
        Rectangle()
            .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 178/255, green: 36/255, blue: 239/255), Color(red: 117/255, green: 121/255, blue: 255/255)]), startPoint: .top, endPoint: .bottom ))
            .overlay(
                ZStack{
                    VStack{
                        HStack{
                            
                            Spacer()
                            Image(systemName: "checkmark.circle")
                                .foregroundColor(Color.green)
                                .font(.system(size: 50))
                            Text(String(self.correct))
                                .font(Font.system(size:50, design: .default))
                                .fontWeight(.bold)
                                .foregroundColor(Color.green)
                            Image(systemName: "xmark.circle")
                                .foregroundColor(Color.red)
                                .font(.system(size: 50))
                            Text(String(self.wrong))
                                .font(Font.system(size:50, design: .default))
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                        }
                        .padding()
                        
                        Text("Quiz 4")
                            .font(Font.system(size:50, design: .default))
                        Text("I am Quiz 3").font(Font.system(size:25, design: .default))
                            .fontWeight(.bold)
                        Spacer()
                        
                        Button(action: {
                            self.select = "A"
                        }) {
                            Text("According to Apple survey, most consumers will not use the front camera, so it will be removed in the iPhone 14.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "A"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        Button(action: {
                            self.select = "B"
                        }) {
                            Text("We can trade in our current iPad and get credit toward a new one.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "B"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        Button(action: {
                            self.select = "C"
                        }) {
                            Text("The Swift Student Challenge is an annual challenge.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "C"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        if select != answer && isSubimt{
                            Text("There is no news so far that IPohne will remove the front camera")
                                .font(Font.system(size:20, design: .default))
                                .foregroundColor(Color.red)
                                .padding()
                        }
                        
                        Spacer()
                        
                        HStack(){
                            Button(action: {
                                checkAnswer()
                            }) {
                                Text("Subimt👌")
                                    .fontWeight(.bold)
                                    .font(.largeTitle)
                                    .padding()
                                    .foregroundColor(Color.white)
                                    .frame(width: UIScreen.main.bounds.width/5)
                                    .border(Color.white, width: 5)
                            }
                            .disabled(isSubimt ? true:false)
                            if isSubimt {
                                Button(action: {
                                    self.nowPage = "Congratulations"
                                }) {
                                    Text("Next")
                                        .fontWeight(.bold)
                                        .font(.largeTitle)
                                        .padding()
                                        .foregroundColor(Color.white)
                                        .frame(width: UIScreen.main.bounds.width/5)
                                        .border(Color.white, width: 5)
                                }
                            }
                        }
                        .padding(.bottom, 50)
                    }
                }
                .sheet(isPresented: $showHelpView) {
                    OpenView()
                }
            )
    }
    
    func color(option: String) -> Color{
        if option == select{
            if select==answer && isSubimt{
                return Color.green 
            }
            else if select != answer && isSubimt{
                return Color.red 
            }
            return Color.white
        }
        else{
            return Color.gray
        }
    }
    
    func checkAnswer(){
        if select != ""{
            self.isSubimt.toggle()
            if select == answer{
                correct += 1
            }
            else{
                wrong += 1
            }
        }
    }
}
