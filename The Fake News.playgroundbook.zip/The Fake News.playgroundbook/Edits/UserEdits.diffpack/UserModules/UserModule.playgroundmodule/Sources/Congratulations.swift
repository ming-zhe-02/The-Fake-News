
import SwiftUI


public struct Congratulations: View {
    @Binding var nowPage: String
    
    // alytlics
    @Binding var correct: Int
    @Binding var wrong: Int
    
    public var body: some View {
        Rectangle()
            .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 178/255, green: 36/255, blue: 239/255), Color(red: 117/255, green: 121/255, blue: 255/255)]), startPoint: .top, endPoint: .bottom ))
            .overlay(
                ZStack{
                    VStack(spacing: 30){
                        Text("🥳🥳🥳").font(Font.system(size:60, design: .default))
                        Text("Congratulations you got  \(correct)/4！！！").font(Font.system(size:25, design: .default))
                            .fontWeight(.bold)
                        Text("Congratulations, you have completed the basic understanding and judgment of fake news, \n \n There is an old saying in Chinese: the wise does not buy rumours. \n If everyone can distinguish fake news, the spread of fake news can be stopped.").font(Font.system(size:25, design: .default))
                        Button(action: {
                            self.nowPage = "main"
                            self.correct = 0
                            self.wrong = 0
                        }) {
                            Text("AGAIN")
                                .fontWeight(.bold)
                                .font(.largeTitle)
                                .padding(10)
                                .foregroundColor(Color.white)
                                .frame(width: UIScreen.main.bounds.width/5)
                                .border(Color.white, width: 5)
                        }
                        
                    }
                }
            )
    }
}





