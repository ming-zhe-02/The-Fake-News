import SwiftUI


public struct Quiz2: View {
    @Binding var nowPage: String
    
    // alytlics
    @Binding var correct: Int
    @Binding var wrong: Int
    
    @State var select = ""
    @State var answer = "C"
    @State var isSubimt = false
    
    public var body: some View {
        Rectangle()
            .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 178/255, green: 36/255, blue: 239/255), Color(red: 117/255, green: 121/255, blue: 255/255)]), startPoint: .top, endPoint: .bottom ))
            .overlay(
                ZStack{
                    VStack{
                        HStack{
                            
                            Spacer()
                            Image(systemName: "checkmark.circle")
                                .foregroundColor(Color.green)
                                .font(.system(size: 50))
                            Text(String(self.correct))
                                .font(Font.system(size:50, design: .default))
                                .fontWeight(.bold)
                                .foregroundColor(Color.green)
                            Image(systemName: "xmark.circle")
                                .foregroundColor(Color.red)
                                .font(.system(size: 50))
                            Text(String(self.wrong))
                                .font(Font.system(size:50, design: .default))
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                        }
                        .padding()
                        
                        Text("Quiz 2")
                            .font(Font.system(size:50, design: .default))
                        Text("Choose which of the following is fake news.").font(Font.system(size:25, design: .default))
                            .fontWeight(.bold)
                        Spacer()
                        
                        Button(action: {
                            self.select = "A"
                        }) {
                            Text("When you in Apple Teacher Learning Center collect all six badges on either iPad or Mac you can get recognized as an Apple Teacher.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "A"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        Button(action: {
                            self.select = "B"
                        }) {
                            Text("Apple has been part of the ConnectED initiative since 2014, pledging to 114 underserved schools across the country. We've donated an iPad to every student, a Mac and iPad to every teacher, and an Apple TV to every classroom.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "B"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        Button(action: {
                            self.select = "C"
                        }) {
                            Text("The 2022 WWDC is from May 6 to 10.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "C"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        if select != answer && isSubimt{
                            Text("Join developers worldwide from June 6 to 10 for an inspiring week of technology and community. Get a first look at Apple’s latest platforms and technologies in sessions, explore the newest tools and tips, and connect with Apple experts in labs and digital lounges. All online and at no cost.")
                                .font(Font.system(size:20, design: .default))
                                .foregroundColor(Color.red)
                                .padding()
                        }
                        
                        Spacer()
                        
                        HStack(){
                            Button(action: {
                                checkAnswer()
                            }) {
                                Text("Subimt👌")
                                    .fontWeight(.bold)
                                    .font(.largeTitle)
                                    .padding()
                                    .foregroundColor(Color.white)
                                    .frame(width: UIScreen.main.bounds.width/5)
                                    .border(Color.white, width: 5)
                            }
                            .disabled(isSubimt ? true:false)
                            if isSubimt {
                                Button(action: {
                                    self.nowPage = "Quiz3"
                                }) {
                                    Text("Next")
                                        .fontWeight(.bold)
                                        .font(.largeTitle)
                                        .padding()
                                        .foregroundColor(Color.white)
                                        .frame(width: UIScreen.main.bounds.width/5)
                                        .border(Color.white, width: 5)
                                }
                            }
                        }
                        .padding(.bottom, 50)
                    }
                }
            )
    }
    
    func color(option: String) -> Color{
        if option == select{
            if select==answer && isSubimt{
                return Color.green 
            }
            else if select != answer && isSubimt{
                return Color.red 
            }
            return Color.white
        }
        else{
            return Color.gray
        }
    }
    
    func checkAnswer(){
        if select != ""{
            self.isSubimt.toggle()
            if select == answer{
                correct += 1
            }
            else{
                wrong += 1
            }
        }
    }
}
