import SwiftUI



public struct ContentView: View{
    @State var nowPage: String = "main"
    
    // alytlics
    @State var correct = 0
    @State var wrong = 0
    
    public var body: some View {
        if nowPage == "main" {
            Rectangle()
                .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 178/255, green: 36/255, blue: 239/255), Color(red: 117/255, green: 121/255, blue: 255/255)]), startPoint: .top, endPoint: .bottom ))
                .overlay(
                    ZStack{
                        VStack(spacing: 30){
                            
                            Text("The FAKE NEWS 📣").font(Font.system(size:50, design: .default))
                            
                            Text("There is an old saying in Chinese: Three Liars Make a Tiger, It's mean Three people spreading reports of a tiger makes you believe that there is one around, This is the power of fake news, There is the fake news can be found everywhere in the Ukraine-Russian war and epidemic, the wrong information leads to wrong judgment, So, how to judge the correct message It's our generation's problem, and let's learn more about fake news! ").font(Font.system(size:25, design: .default))
                                .padding()
                            
                            Button(action: {
                                self.nowPage = "Knowledge"
                            }) {
                                Text("Let's Start 😎")
                                    .fontWeight(.bold)
                                    .font(.largeTitle)
                                    .padding()
                                    .foregroundColor(Color.white)
                                    .border(Color.white, width: 5)
                            }
                        }
                    }
                )
        }
        else if nowPage == "Knowledge" {
            Knowledge(nowPage: self.$nowPage)
        }
        else if nowPage == "Quiz1" {
            Quiz1(nowPage: self.$nowPage, correct: self.$correct, wrong: self.$wrong)
        }
        else if nowPage == "Quiz2" {
            Quiz2(nowPage: self.$nowPage, correct: self.$correct, wrong: self.$wrong)
        }
        else if nowPage == "Quiz3" {
            Quiz3(nowPage: self.$nowPage, correct: self.$correct, wrong: self.$wrong)
        }
        else if nowPage == "Quiz4" {
            Quiz4(nowPage: self.$nowPage, correct: self.$correct, wrong: self.$wrong)
        }
        else if nowPage == "Congratulations" {
            Congratulations(nowPage: self.$nowPage, correct: self.$correct, wrong: self.$wrong)
        }
    }
    
    
    public init() {}
}


//在中文中我們有句話叫三人成虎，意思是說當有三個人說街道上有老虎時，原本不相信的人也會跟著相信了，這便是假新聞的可怕，在這次烏俄戰爭以及疫情中可以發現到處都是假新聞，因此如何判斷消息的正確是我們這個世代必須面臨得問題，接著讓我們一起來更認識假新聞吧

