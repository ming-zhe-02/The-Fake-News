import SwiftUI


public struct Quiz1: View {
    @Binding var nowPage: String
    
    // alytlics
    @Binding var correct: Int
    @Binding var wrong: Int
    
    @State var select = ""
    @State var answer = "A"
    @State var isSubimt = false
    @State var showHelpView = false
    
    public var body: some View {
        Rectangle()
            .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 178/255, green: 36/255, blue: 239/255), Color(red: 117/255, green: 121/255, blue: 255/255)]), startPoint: .top, endPoint: .bottom ))
            .overlay(
                ZStack{
                    VStack{
                        HStack{
                            
                            Spacer()
                            Image(systemName: "checkmark.circle")
                                .foregroundColor(Color.green)
                                .font(.system(size: 50))
                            Text(String(self.correct))
                                .font(Font.system(size:50, design: .default))
                                .fontWeight(.bold)
                                .foregroundColor(Color.green)
                            Image(systemName: "xmark.circle")
                                .foregroundColor(Color.red)
                                .font(.system(size: 50))
                            Text(String(self.wrong))
                                .font(Font.system(size:50, design: .default))
                                .fontWeight(.bold)
                                .foregroundColor(Color.red)
                        }
                        .padding()
                        
                        Text("Quiz 1")
                            .font(Font.system(size:50, design: .default))
                        Text("Choose which of the following is fake news.").font(Font.system(size:25, design: .default))
                            .fontWeight(.bold)
                        Spacer()
                        
                        Button(action: {
                            self.select = "A"
                        }) {
                            Text("By 2060, all Apple products will be made with 100% clean energy.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "A"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        Button(action: {
                            self.select = "B"
                        }) {
                            Text("In Apple data centers use 100% renewable electricity to power siri, iMessage, and iCloud. So we can say siri runs on clean energy.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "B"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        Button(action: {
                            self.select = "C"
                        }) {
                            Text("Since 2017, 100% of the wood fiber in Apple's paper and packaging comes from recycled or responsible sources.")
                                .foregroundColor(Color.white)
                                .font(Font.system(size:30, design: .default))
                                .padding(20)
                                .frame(width: UIScreen.main.bounds.width/3)
                        }
                        .border(color(option: "C"), width: 5)
                        .cornerRadius(20)
                        .padding(.top, 10)
                        .disabled(isSubimt ? true:false)
                        
                        if select != answer && isSubimt{
                            Text("The biggest part of our carbon footprint comes from the electricity used to build the products you love. By switching to clean energy across our supply chain, we can erase the majority of that footprint. Since 2015, Apple’s Supplier Clean Energy Program has helped our manufacturing suppliers transition to renewable electricity generated from solar, wind, and other renewable projects. And by 2030, all our products will be made with 100% clean energy, so is 2030 not 2060, The answer is A")
                                .font(Font.system(size:20, design: .default))
                                .foregroundColor(Color.red)
                                .padding()
                        }
                        
                        Spacer()
                        
                        HStack(){
                            Button(action: {
                                checkAnswer()
                            }) {
                                Text("Subimt👌")
                                    .fontWeight(.bold)
                                    .font(.largeTitle)
                                    .padding()
                                    .foregroundColor(Color.white)
                                    .frame(width: UIScreen.main.bounds.width/5)
                                    .border(Color.white, width: 5)
                            }
                            .disabled(isSubimt ? true:false)
                            if isSubimt {
                                Button(action: {
                                    self.nowPage = "Quiz2"
                                }) {
                                    Text("Next")
                                        .fontWeight(.bold)
                                        .font(.largeTitle)
                                        .padding()
                                        .foregroundColor(Color.white)
                                        .frame(width: UIScreen.main.bounds.width/5)
                                        .border(Color.white, width: 5)
                                }
                            }
                        }
                        .padding(.bottom, 50)
                    }
                }
                .sheet(isPresented: $showHelpView) {
                    OpenView()
                }
            )
    }
    
    func color(option: String) -> Color{
        if option == select{
            if select==answer && isSubimt{
                return Color.green 
            }
            else if select != answer && isSubimt{
                return Color.red 
            }
            return Color.white
        }
        else{
            return Color.gray
        }
    }
    
    func checkAnswer(){
        if select != ""{
            self.isSubimt.toggle()
            if select == answer{
                correct += 1
            }
            else{
                wrong += 1
            }
        }
    }
}
